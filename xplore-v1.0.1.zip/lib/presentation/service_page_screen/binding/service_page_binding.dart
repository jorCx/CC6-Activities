import '../controller/service_page_controller.dart';
import 'package:get/get.dart';

/// A binding class for the ServicePageScreen.
///
/// This class ensures that the ServicePageController is created when the
/// ServicePageScreen is first loaded.
class ServicePageBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => ServicePageController());
  }
}
