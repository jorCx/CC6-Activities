import 'controller/service_page_controller.dart';
import 'package:flutter/material.dart';
import 'package:xplore/core/app_export.dart';
import 'package:xplore/presentation/landing_page_container_page/landing_page_container_page.dart';
import 'package:xplore/widgets/custom_bottom_bar.dart';
import 'package:xplore/widgets/custom_button.dart';

class ServicePageScreen extends GetWidget<ServicePageController> {
  const ServicePageScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            backgroundColor: ColorConstant.black900,
            body: Container(
                width: double.maxFinite,
                padding: getPadding(left: 23, top: 17, right: 23, bottom: 17),
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      CustomImageView(
                          svgPath: ImageConstant.imgArrowleft,
                          height: getSize(24),
                          width: getSize(24),
                          margin: getMargin(top: 1),
                          onTap: () {
                            onTapImgArrowleft();
                          }),
                      CustomImageView(
                          imagePath: ImageConstant.imgRectangle13,
                          height: getVerticalSize(160),
                          width: getHorizontalSize(320),
                          radius: BorderRadius.circular(getHorizontalSize(10)),
                          margin: getMargin(left: 7, top: 7)),
                      Padding(
                          padding: getPadding(left: 7, top: 10),
                          child: Text("msg_joric_l_bartolo".tr,
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.left,
                              style: AppStyle.txtPoppinsBold18)),
                      CustomButton(
                          height: getVerticalSize(30),
                          width: getHorizontalSize(90),
                          text: "lbl_log_out".tr,
                          margin: getMargin(left: 7, top: 2),
                          variant: ButtonVariant.FillWhiteA700,
                          shape: ButtonShape.RoundedBorder10,
                          padding: ButtonPadding.PaddingAll6,
                          fontStyle: ButtonFontStyle.PoppinsBold12,
                          onTap: () {
                            onTapLogout();
                          }),
                      Padding(
                          padding: getPadding(left: 7, top: 14),
                          child: Text("lbl_account_info".tr,
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.left,
                              style: AppStyle.txtPoppinsBold14)),
                      Container(
                          width: getHorizontalSize(297),
                          margin: getMargin(left: 7, top: 8, right: 24),
                          child: Text("msg_hi_i_m_joric_i_m".tr,
                              maxLines: null,
                              textAlign: TextAlign.left,
                              style: AppStyle.txtPoppinsBold10)),
                      Padding(
                          padding: getPadding(left: 6, top: 12),
                          child: Text("lbl_recent_rides".tr,
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.left,
                              style: AppStyle.txtPoppinsBold14)),
                      Padding(
                          padding: getPadding(left: 6, top: 15, right: 25),
                          child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Padding(
                                    padding: getPadding(bottom: 45),
                                    child: Column(
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        children: [
                                          CustomImageView(
                                              imagePath:
                                                  ImageConstant.imgEllipse1,
                                              height: getSize(50),
                                              width: getSize(50),
                                              radius: BorderRadius.circular(
                                                  getHorizontalSize(25))),
                                          CustomImageView(
                                              imagePath:
                                                  ImageConstant.imgEllipse2,
                                              height: getSize(50),
                                              width: getSize(50),
                                              radius: BorderRadius.circular(
                                                  getHorizontalSize(25)),
                                              margin: getMargin(top: 16)),
                                          CustomImageView(
                                              imagePath:
                                                  ImageConstant.imgEllipse3,
                                              height: getSize(50),
                                              width: getSize(50),
                                              radius: BorderRadius.circular(
                                                  getHorizontalSize(25)),
                                              margin: getMargin(top: 12))
                                        ])),
                                Expanded(
                                    child: Padding(
                                        padding: getPadding(left: 10, top: 4),
                                        child: Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            mainAxisAlignment:
                                                MainAxisAlignment.start,
                                            children: [
                                              Padding(
                                                  padding: getPadding(right: 3),
                                                  child: Row(children: [
                                                    Text("lbl_panay_capiz".tr,
                                                        overflow: TextOverflow
                                                            .ellipsis,
                                                        textAlign:
                                                            TextAlign.left,
                                                        style: AppStyle
                                                            .txtPoppinsSemiBold14WhiteA700),
                                                    Padding(
                                                        padding: getPadding(
                                                            left: 73,
                                                            top: 4,
                                                            bottom: 2),
                                                        child: Text(
                                                            "lbl_17th_june_2023"
                                                                .tr,
                                                            overflow:
                                                                TextOverflow
                                                                    .ellipsis,
                                                            textAlign:
                                                                TextAlign.left,
                                                            style: AppStyle
                                                                .txtPoppinsSemiBold9Bluegray400))
                                                  ])),
                                              Padding(
                                                  padding: getPadding(top: 2),
                                                  child: Row(children: [
                                                    CustomImageView(
                                                        svgPath: ImageConstant
                                                            .imgStar,
                                                        height:
                                                            getVerticalSize(12),
                                                        width:
                                                            getHorizontalSize(
                                                                13)),
                                                    CustomImageView(
                                                        svgPath: ImageConstant
                                                            .imgStar,
                                                        height:
                                                            getVerticalSize(12),
                                                        width:
                                                            getHorizontalSize(
                                                                13),
                                                        margin:
                                                            getMargin(left: 3)),
                                                    CustomImageView(
                                                        svgPath: ImageConstant
                                                            .imgStar,
                                                        height:
                                                            getVerticalSize(12),
                                                        width:
                                                            getHorizontalSize(
                                                                13),
                                                        margin:
                                                            getMargin(left: 3)),
                                                    CustomImageView(
                                                        svgPath: ImageConstant
                                                            .imgStar,
                                                        height:
                                                            getVerticalSize(12),
                                                        width:
                                                            getHorizontalSize(
                                                                13),
                                                        margin:
                                                            getMargin(left: 2)),
                                                    CustomImageView(
                                                        svgPath: ImageConstant
                                                            .imgStar,
                                                        height:
                                                            getVerticalSize(12),
                                                        width:
                                                            getHorizontalSize(
                                                                13),
                                                        margin:
                                                            getMargin(left: 3))
                                                  ])),
                                              Padding(
                                                  padding: getPadding(
                                                      left: 1,
                                                      top: 30,
                                                      right: 1),
                                                  child: Row(children: [
                                                    Text("lbl_basiao_capiz".tr,
                                                        overflow: TextOverflow
                                                            .ellipsis,
                                                        textAlign:
                                                            TextAlign.left,
                                                        style: AppStyle
                                                            .txtPoppinsSemiBold14WhiteA700),
                                                    Padding(
                                                        padding: getPadding(
                                                            left: 70,
                                                            top: 5,
                                                            bottom: 1),
                                                        child: Text(
                                                            "lbl_23rd_april_2023"
                                                                .tr,
                                                            overflow:
                                                                TextOverflow
                                                                    .ellipsis,
                                                            textAlign:
                                                                TextAlign.left,
                                                            style: AppStyle
                                                                .txtPoppinsSemiBold9Bluegray400))
                                                  ])),
                                              Padding(
                                                  padding: getPadding(
                                                      left: 1, top: 3),
                                                  child: Row(children: [
                                                    CustomImageView(
                                                        svgPath: ImageConstant
                                                            .imgStar,
                                                        height:
                                                            getVerticalSize(12),
                                                        width:
                                                            getHorizontalSize(
                                                                13)),
                                                    CustomImageView(
                                                        svgPath: ImageConstant
                                                            .imgStar,
                                                        height:
                                                            getVerticalSize(12),
                                                        width:
                                                            getHorizontalSize(
                                                                13),
                                                        margin:
                                                            getMargin(left: 3)),
                                                    CustomImageView(
                                                        svgPath: ImageConstant
                                                            .imgStar,
                                                        height:
                                                            getVerticalSize(12),
                                                        width:
                                                            getHorizontalSize(
                                                                13),
                                                        margin:
                                                            getMargin(left: 3)),
                                                    CustomImageView(
                                                        svgPath: ImageConstant
                                                            .imgStar,
                                                        height:
                                                            getVerticalSize(12),
                                                        width:
                                                            getHorizontalSize(
                                                                13),
                                                        margin:
                                                            getMargin(left: 2)),
                                                    CustomImageView(
                                                        svgPath: ImageConstant
                                                            .imgStar,
                                                        height:
                                                            getVerticalSize(12),
                                                        width:
                                                            getHorizontalSize(
                                                                13),
                                                        margin:
                                                            getMargin(left: 3))
                                                  ])),
                                              Padding(
                                                  padding: getPadding(
                                                      left: 1, top: 25),
                                                  child: Row(children: [
                                                    Text("lbl_bataba_maayon".tr,
                                                        overflow: TextOverflow
                                                            .ellipsis,
                                                        textAlign:
                                                            TextAlign.left,
                                                        style: AppStyle
                                                            .txtPoppinsSemiBold14WhiteA700),
                                                    Padding(
                                                        padding: getPadding(
                                                            left: 47,
                                                            top: 4,
                                                            bottom: 2),
                                                        child: Text(
                                                            "lbl_3rd_march_2023"
                                                                .tr,
                                                            overflow:
                                                                TextOverflow
                                                                    .ellipsis,
                                                            textAlign:
                                                                TextAlign.left,
                                                            style: AppStyle
                                                                .txtPoppinsSemiBold9Bluegray400))
                                                  ])),
                                              Padding(
                                                  padding: getPadding(
                                                      left: 1, top: 1),
                                                  child: Row(children: [
                                                    CustomImageView(
                                                        svgPath: ImageConstant
                                                            .imgStar,
                                                        height:
                                                            getVerticalSize(12),
                                                        width:
                                                            getHorizontalSize(
                                                                13)),
                                                    CustomImageView(
                                                        svgPath: ImageConstant
                                                            .imgStar,
                                                        height:
                                                            getVerticalSize(12),
                                                        width:
                                                            getHorizontalSize(
                                                                13),
                                                        margin:
                                                            getMargin(left: 3)),
                                                    CustomImageView(
                                                        svgPath: ImageConstant
                                                            .imgStar,
                                                        height:
                                                            getVerticalSize(12),
                                                        width:
                                                            getHorizontalSize(
                                                                13),
                                                        margin:
                                                            getMargin(left: 3)),
                                                    CustomImageView(
                                                        svgPath: ImageConstant
                                                            .imgStar,
                                                        height:
                                                            getVerticalSize(12),
                                                        width:
                                                            getHorizontalSize(
                                                                13),
                                                        margin:
                                                            getMargin(left: 2)),
                                                    CustomImageView(
                                                        svgPath: ImageConstant
                                                            .imgStar,
                                                        height:
                                                            getVerticalSize(12),
                                                        width:
                                                            getHorizontalSize(
                                                                13),
                                                        margin:
                                                            getMargin(left: 3))
                                                  ])),
                                              Padding(
                                                  padding: getPadding(
                                                      left: 64, top: 37),
                                                  child: Text(
                                                      "lbl_see_all_23".tr,
                                                      overflow:
                                                          TextOverflow.ellipsis,
                                                      textAlign: TextAlign.left,
                                                      style: AppStyle
                                                          .txtPoppinsSemiBold12))
                                            ])))
                              ]))
                    ])),
            bottomNavigationBar:
                CustomBottomBar(onChanged: (BottomBarEnum type) {
              Get.toNamed(getCurrentRoute(type), id: 1);
            })));
  }

  ///Handling route based on bottom click actions
  String getCurrentRoute(BottomBarEnum type) {
    switch (type) {
      case BottomBarEnum.Home:
        return AppRoutes.landingPageContainerPage;
      case BottomBarEnum.Search:
        return "/";
      case BottomBarEnum.Start:
        return "/";
      case BottomBarEnum.Dashboard:
        return "/";
      case BottomBarEnum.Profile:
        return "/";
      default:
        return "/";
    }
  }

  ///Handling page based on route
  Widget getCurrentPage(String currentRoute) {
    switch (currentRoute) {
      case AppRoutes.landingPageContainerPage:
        return LandingPageContainerPage();
      default:
        return DefaultWidget();
    }
  }

  /// Navigates to the previous screen.
  ///
  /// When the action is triggered, this function uses the [Get] library to
  /// navigate to the previous screen in the navigation stack.
  onTapImgArrowleft() {
    Get.back();
  }

  /// Navigates to the returningUserScreen when the action is triggered.

  /// When the action is triggered, this function uses the `Get` package to
  /// push the named route for the returningUserScreen.
  onTapLogout() {
    Get.toNamed(
      AppRoutes.returningUserScreen,
    );
  }
}
