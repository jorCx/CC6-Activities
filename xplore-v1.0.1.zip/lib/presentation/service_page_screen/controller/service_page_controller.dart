import 'package:xplore/core/app_export.dart';
import 'package:xplore/presentation/service_page_screen/models/service_page_model.dart';

/// A controller class for the ServicePageScreen.
///
/// This class manages the state of the ServicePageScreen, including the
/// current servicePageModelObj
class ServicePageController extends GetxController {
  Rx<ServicePageModel> servicePageModelObj = ServicePageModel().obs;
}
