import '../controller/returning_user_controller.dart';
import 'package:get/get.dart';

/// A binding class for the ReturningUserScreen.
///
/// This class ensures that the ReturningUserController is created when the
/// ReturningUserScreen is first loaded.
class ReturningUserBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => ReturningUserController());
  }
}
