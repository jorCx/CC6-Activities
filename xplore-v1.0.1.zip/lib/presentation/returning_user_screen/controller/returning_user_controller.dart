import 'package:xplore/core/app_export.dart';
import 'package:xplore/presentation/returning_user_screen/models/returning_user_model.dart';
import 'package:flutter/material.dart';

/// A controller class for the ReturningUserScreen.
///
/// This class manages the state of the ReturningUserScreen, including the
/// current returningUserModelObj
class ReturningUserController extends GetxController {
  TextEditingController emailController = TextEditingController();

  TextEditingController passwordController = TextEditingController();

  Rx<ReturningUserModel> returningUserModelObj = ReturningUserModel().obs;

  @override
  void onClose() {
    super.onClose();
    emailController.dispose();
    passwordController.dispose();
  }
}
