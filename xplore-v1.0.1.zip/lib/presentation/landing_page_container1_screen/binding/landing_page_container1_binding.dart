import '../controller/landing_page_container1_controller.dart';
import 'package:get/get.dart';

/// A binding class for the LandingPageContainer1Screen.
///
/// This class ensures that the LandingPageContainer1Controller is created when the
/// LandingPageContainer1Screen is first loaded.
class LandingPageContainer1Binding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => LandingPageContainer1Controller());
  }
}
