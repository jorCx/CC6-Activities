import 'package:xplore/core/app_export.dart';
import 'package:xplore/presentation/landing_page_container1_screen/models/landing_page_container1_model.dart';

/// A controller class for the LandingPageContainer1Screen.
///
/// This class manages the state of the LandingPageContainer1Screen, including the
/// current landingPageContainer1ModelObj
class LandingPageContainer1Controller extends GetxController {
  Rx<LandingPageContainer1Model> landingPageContainer1ModelObj =
      LandingPageContainer1Model().obs;
}
