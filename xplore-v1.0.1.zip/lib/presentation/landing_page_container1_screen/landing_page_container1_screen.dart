import 'controller/landing_page_container1_controller.dart';
import 'package:flutter/material.dart';
import 'package:xplore/core/app_export.dart';
import 'package:xplore/presentation/landing_page_container_page/landing_page_container_page.dart';
import 'package:xplore/widgets/custom_bottom_bar.dart';

class LandingPageContainer1Screen
    extends GetWidget<LandingPageContainer1Controller> {
  const LandingPageContainer1Screen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            backgroundColor: ColorConstant.black900,
            body: Navigator(
                key: Get.nestedKey(1),
                initialRoute: AppRoutes.landingPageContainerPage,
                onGenerateRoute: (routeSetting) => GetPageRoute(
                    page: () => getCurrentPage(routeSetting.name!),
                    transition: Transition.noTransition)),
            bottomNavigationBar:
                CustomBottomBar(onChanged: (BottomBarEnum type) {
              Get.toNamed(getCurrentRoute(type), id: 1);
            })));
  }

  ///Handling route based on bottom click actions
  String getCurrentRoute(BottomBarEnum type) {
    switch (type) {
      case BottomBarEnum.Home:
        return AppRoutes.landingPageContainerPage;
      case BottomBarEnum.Search:
        return "/";
      case BottomBarEnum.Start:
        return "/";
      case BottomBarEnum.Dashboard:
        return "/";
      case BottomBarEnum.Profile:
        return "/";
      default:
        return "/";
    }
  }

  ///Handling page based on route
  Widget getCurrentPage(String currentRoute) {
    switch (currentRoute) {
      case AppRoutes.landingPageContainerPage:
        return LandingPageContainerPage();
      default:
        return DefaultWidget();
    }
  }
}
