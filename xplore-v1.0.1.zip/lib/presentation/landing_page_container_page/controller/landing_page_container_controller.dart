import 'package:xplore/core/app_export.dart';
import 'package:xplore/presentation/landing_page_container_page/models/landing_page_container_model.dart';

/// A controller class for the LandingPageContainerPage.
///
/// This class manages the state of the LandingPageContainerPage, including the
/// current landingPageContainerModelObj
class LandingPageContainerController extends GetxController {
  LandingPageContainerController(this.landingPageContainerModelObj);

  Rx<LandingPageContainerModel> landingPageContainerModelObj;

  @override
  void onReady() {
    Future.delayed(const Duration(milliseconds: 3000), () {
      Get.toNamed(
        AppRoutes.servicePageScreen,
      );
    });
  }
}
