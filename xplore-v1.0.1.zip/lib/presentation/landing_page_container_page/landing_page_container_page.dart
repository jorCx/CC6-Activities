import '../landing_page_container_page/widgets/listrectangleth_item_widget.dart';
import 'controller/landing_page_container_controller.dart';
import 'models/landing_page_container_model.dart';
import 'models/listrectangleth_item_model.dart';
import 'package:flutter/material.dart';
import 'package:xplore/core/app_export.dart';
import 'package:xplore/widgets/app_bar/custom_app_bar.dart';
import 'package:xplore/widgets/custom_button.dart';

// ignore_for_file: must_be_immutable
class LandingPageContainerPage extends StatelessWidget {
  LandingPageContainerPage({Key? key}) : super(key: key);

  LandingPageContainerController controller =
      Get.put(LandingPageContainerController(LandingPageContainerModel().obs));

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            backgroundColor: ColorConstant.black900,
            appBar: CustomAppBar(
                height: getVerticalSize(56),
                title: Padding(
                    padding: getPadding(left: 32),
                    child: Text("lbl_xplore".tr,
                        overflow: TextOverflow.ellipsis,
                        textAlign: TextAlign.left,
                        style: AppStyle.txtPoppinsBold25)),
                actions: [
                  CustomImageView(
                      svgPath: ImageConstant.imgWhhnotification,
                      height: getSize(32),
                      width: getSize(32),
                      margin:
                          getMargin(left: 23, top: 9, right: 23, bottom: 14))
                ]),
            body: Container(
                width: double.maxFinite,
                padding: getPadding(left: 13, top: 5, right: 13, bottom: 5),
                child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Container(
                          margin: getMargin(left: 25, right: 22),
                          padding: getPadding(
                              left: 11, top: 13, right: 11, bottom: 13),
                          decoration: AppDecoration.fillAmber700.copyWith(
                              borderRadius: BorderRadiusStyle.roundedBorder10),
                          child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                CustomImageView(
                                    svgPath: ImageConstant.imgSearch,
                                    height: getSize(17),
                                    width: getSize(17),
                                    margin: getMargin(bottom: 5)),
                                Padding(
                                    padding:
                                        getPadding(left: 20, top: 2, right: 52),
                                    child: Text("msg_where_will_you_ride".tr,
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style: AppStyle.txtPoppinsSemiBold14))
                              ])),
                      Padding(
                          padding: getPadding(left: 14, top: 30),
                          child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text("lbl_recents".tr,
                                    overflow: TextOverflow.ellipsis,
                                    textAlign: TextAlign.left,
                                    style: AppStyle.txtPoppinsBold18),
                                Padding(
                                    padding: getPadding(top: 6, bottom: 2),
                                    child: Text("lbl_see_all_17".tr,
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style: AppStyle.txtPoppinsBold12))
                              ])),
                      SizedBox(
                          height: getVerticalSize(102),
                          child: Obx(() => ListView.separated(
                              padding: getPadding(left: 16, top: 12, right: 1),
                              scrollDirection: Axis.horizontal,
                              separatorBuilder: (context, index) {
                                return SizedBox(height: getVerticalSize(30));
                              },
                              itemCount: controller.landingPageContainerModelObj
                                  .value.listrectanglethItemList.value.length,
                              itemBuilder: (context, index) {
                                ListrectanglethItemModel model = controller
                                    .landingPageContainerModelObj
                                    .value
                                    .listrectanglethItemList
                                    .value[index];
                                return ListrectanglethItemWidget(model);
                              }))),
                      Align(
                          alignment: Alignment.centerRight,
                          child: Padding(
                              padding: getPadding(left: 33, top: 6, right: 15),
                              child: Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text("lbl_panay_capiz".tr,
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style: AppStyle.txtPoppinsSemiBold9),
                                    Text("msg_pontevedra_capiz".tr,
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style: AppStyle.txtPoppinsSemiBold9),
                                    Text("lbl_basiao_ivisan".tr,
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style: AppStyle.txtPoppinsSemiBold9)
                                  ]))),
                      Padding(
                          padding: getPadding(left: 14, top: 9),
                          child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text("lbl_featured".tr,
                                    overflow: TextOverflow.ellipsis,
                                    textAlign: TextAlign.left,
                                    style: AppStyle.txtPoppinsBold18),
                                Padding(
                                    padding: getPadding(top: 6, bottom: 2),
                                    child: Text("lbl_see_all_33".tr,
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style: AppStyle.txtPoppinsBold12))
                              ])),
                      Padding(
                          padding: getPadding(left: 16, top: 13, right: 1),
                          child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Expanded(
                                    child: CustomImageView(
                                        imagePath: ImageConstant.imgRectangle6,
                                        height: getSize(90),
                                        width: getSize(90),
                                        radius: BorderRadius.circular(
                                            getHorizontalSize(10)),
                                        margin: getMargin(right: 15))),
                                Expanded(
                                    child: CustomImageView(
                                        imagePath: ImageConstant.imgRectangle7,
                                        height: getSize(90),
                                        width: getSize(90),
                                        radius: BorderRadius.circular(
                                            getHorizontalSize(10)),
                                        margin:
                                            getMargin(left: 15, right: 15))),
                                Expanded(
                                    child: CustomImageView(
                                        imagePath: ImageConstant.imgRectangle8,
                                        height: getSize(90),
                                        width: getSize(90),
                                        radius: BorderRadius.circular(
                                            getHorizontalSize(10)),
                                        margin: getMargin(left: 15)))
                              ])),
                      Padding(
                          padding: getPadding(left: 21, top: 6, right: 7),
                          child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text("lbl_batabat_maayon".tr,
                                    overflow: TextOverflow.ellipsis,
                                    textAlign: TextAlign.left,
                                    style: AppStyle.txtPoppinsSemiBold9),
                                Text("lbl_panit_an_capiz".tr,
                                    overflow: TextOverflow.ellipsis,
                                    textAlign: TextAlign.left,
                                    style: AppStyle.txtPoppinsSemiBold9),
                                Text("msg_roxas_city_capiz".tr,
                                    overflow: TextOverflow.ellipsis,
                                    textAlign: TextAlign.left,
                                    style: AppStyle.txtPoppinsSemiBold9)
                              ])),
                      Padding(
                          padding: getPadding(left: 12, top: 8),
                          child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text("lbl_discover".tr,
                                    overflow: TextOverflow.ellipsis,
                                    textAlign: TextAlign.left,
                                    style: AppStyle.txtPoppinsBold18),
                                Padding(
                                    padding: getPadding(top: 7, bottom: 1),
                                    child: Text("lbl_see_all_29".tr,
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style: AppStyle.txtPoppinsBold12))
                              ])),
                      Padding(
                          padding: getPadding(left: 16, top: 13, right: 1),
                          child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Expanded(
                                    child: CustomImageView(
                                        imagePath: ImageConstant.imgRectangle9,
                                        height: getSize(90),
                                        width: getSize(90),
                                        radius: BorderRadius.circular(
                                            getHorizontalSize(10)),
                                        margin: getMargin(right: 15))),
                                Expanded(
                                    child: CustomImageView(
                                        imagePath: ImageConstant.imgRectangle10,
                                        height: getSize(90),
                                        width: getSize(90),
                                        radius: BorderRadius.circular(
                                            getHorizontalSize(10)),
                                        margin:
                                            getMargin(left: 15, right: 15))),
                                Expanded(
                                    child: CustomImageView(
                                        imagePath: ImageConstant.imgRectangle11,
                                        height: getSize(90),
                                        width: getSize(90),
                                        radius: BorderRadius.circular(
                                            getHorizontalSize(10)),
                                        margin: getMargin(left: 15)))
                              ])),
                      Align(
                          alignment: Alignment.centerRight,
                          child: Padding(
                              padding: getPadding(left: 36, top: 2, right: 16),
                              child: Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Padding(
                                        padding: getPadding(top: 4, bottom: 8),
                                        child: Text("lbl_pilar_capiz".tr,
                                            overflow: TextOverflow.ellipsis,
                                            textAlign: TextAlign.left,
                                            style:
                                                AppStyle.txtPoppinsSemiBold9)),
                                    SizedBox(
                                        width: getHorizontalSize(74),
                                        child: Text("msg_road_to_forever".tr,
                                            maxLines: null,
                                            textAlign: TextAlign.center,
                                            style:
                                                AppStyle.txtPoppinsSemiBold9)),
                                    Padding(
                                        padding: getPadding(top: 3, bottom: 8),
                                        child: Text("lbl_kalibo_aklan".tr,
                                            overflow: TextOverflow.ellipsis,
                                            textAlign: TextAlign.left,
                                            style:
                                                AppStyle.txtPoppinsSemiBold9))
                                  ]))),
                      CustomButton(
                          height: getVerticalSize(50),
                          text: "lbl_show_more".tr,
                          margin:
                              getMargin(left: 51, top: 1, right: 46, bottom: 5),
                          variant: ButtonVariant.FillAmber70001,
                          onTap: () {
                            onTapShowmore();
                          })
                    ]))));
  }

  /// Navigates to the servicePageScreen when the action is triggered.

  /// When the action is triggered, this function uses the `Get` package to
  /// push the named route for the servicePageScreen.
  onTapShowmore() {
    Get.offNamed(
      AppRoutes.servicePageScreen,
    );
  }
}
