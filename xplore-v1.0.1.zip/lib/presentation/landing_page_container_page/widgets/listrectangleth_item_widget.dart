import '../controller/landing_page_container_controller.dart';
import '../models/listrectangleth_item_model.dart';
import 'package:flutter/material.dart';
import 'package:xplore/core/app_export.dart';

// ignore: must_be_immutable
class ListrectanglethItemWidget extends StatelessWidget {
  ListrectanglethItemWidget(
    this.listrectanglethItemModelObj, {
    Key? key,
  }) : super(
          key: key,
        );

  ListrectanglethItemModel listrectanglethItemModelObj;

  var controller = Get.find<LandingPageContainerController>();

  @override
  Widget build(BuildContext context) {
    return IntrinsicWidth(
      child: Container(
        height: getSize(
          90,
        ),
        width: getSize(
          90,
        ),
        margin: getMargin(
          right: 30,
        ),
        child: Stack(
          alignment: Alignment.topRight,
          children: [
            CustomImageView(
              imagePath: ImageConstant.imgRectangle3,
              height: getSize(
                90,
              ),
              width: getSize(
                90,
              ),
              radius: BorderRadius.circular(
                getHorizontalSize(
                  10,
                ),
              ),
              alignment: Alignment.center,
            ),
            Align(
              alignment: Alignment.topRight,
              child: Container(
                height: getVerticalSize(
                  17,
                ),
                width: getHorizontalSize(
                  39,
                ),
                margin: getMargin(
                  top: 2,
                  right: 4,
                ),
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    CustomImageView(
                      svgPath: ImageConstant.imgVideocamera,
                      height: getVerticalSize(
                        17,
                      ),
                      width: getHorizontalSize(
                        39,
                      ),
                      radius: BorderRadius.circular(
                        getHorizontalSize(
                          8,
                        ),
                      ),
                      alignment: Alignment.center,
                    ),
                    Align(
                      alignment: Alignment.center,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          CustomImageView(
                            svgPath: ImageConstant.imgStar,
                            height: getVerticalSize(
                              12,
                            ),
                            width: getHorizontalSize(
                              13,
                            ),
                            margin: getMargin(
                              bottom: 2,
                            ),
                          ),
                          Padding(
                            padding: getPadding(
                              left: 2,
                            ),
                            child: Obx(
                              () => Text(
                                listrectanglethItemModelObj.fortysevenTxt.value,
                                overflow: TextOverflow.ellipsis,
                                textAlign: TextAlign.left,
                                style: AppStyle.txtPoppinsSemiBold10,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
