import 'package:get/get.dart';

/// This class is used in the [listrectangleth_item_widget] screen.
class ListrectanglethItemModel {
  Rx<String> fortysevenTxt = Rx("4.7");

  Rx<String>? id = Rx("");
}
