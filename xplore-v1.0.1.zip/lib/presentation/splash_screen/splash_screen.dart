import 'controller/splash_controller.dart';
import 'package:flutter/material.dart';
import 'package:xplore/core/app_export.dart';
import 'package:xplore/widgets/custom_button.dart';

class SplashScreen extends GetWidget<SplashController> {
  const SplashScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            backgroundColor: ColorConstant.black900,
            body: Container(
                width: double.maxFinite,
                padding: getPadding(left: 52, right: 52),
                child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                          width: getHorizontalSize(262),
                          margin: getMargin(left: 9),
                          decoration: AppDecoration.txtOutlineBlack9003f,
                          child: RichText(
                              text: TextSpan(children: [
                                TextSpan(
                                    text: "lbl_x".tr,
                                    style: TextStyle(
                                        color: ColorConstant.amber700,
                                        fontSize: getFontSize(55),
                                        fontFamily: 'Inter',
                                        fontWeight: FontWeight.w800)),
                                TextSpan(
                                    text: "lbl_plore".tr,
                                    style: TextStyle(
                                        color: ColorConstant.whiteA700,
                                        fontSize: getFontSize(30),
                                        fontFamily: 'Inter',
                                        fontWeight: FontWeight.w800)),
                                TextSpan(
                                    text: " ",
                                    style: TextStyle(
                                        color: ColorConstant.amber700,
                                        fontSize: getFontSize(30),
                                        fontFamily: 'Inter',
                                        fontWeight: FontWeight.w800)),
                                TextSpan(
                                    text: "lbl_c".tr,
                                    style: TextStyle(
                                        color: ColorConstant.amber700,
                                        fontSize: getFontSize(30),
                                        fontFamily: 'Inter',
                                        fontWeight: FontWeight.w800)),
                                TextSpan(
                                    text: "lbl_ycling_tracker".tr,
                                    style: TextStyle(
                                        color: ColorConstant.whiteA700,
                                        fontSize: getFontSize(30),
                                        fontFamily: 'Inter',
                                        fontWeight: FontWeight.w800))
                              ]),
                              textAlign: TextAlign.center)),
                      Text("msg_plan_your_next_journey".tr,
                          overflow: TextOverflow.ellipsis,
                          textAlign: TextAlign.left,
                          style: AppStyle.txtPoppinsMedium16),
                      Spacer(),
                      CustomButton(
                          height: getVerticalSize(50),
                          text: "lbl_let_s_go".tr,
                          margin: getMargin(left: 8, right: 13, bottom: 19),
                          onTap: () {
                            onTapLetsgo();
                          })
                    ]))));
  }

  /// Navigates to the returningUserScreen when the action is triggered.

  /// When the action is triggered, this function uses the `Get` package to
  /// push the named route for the returningUserScreen.
  onTapLetsgo() {
    Get.toNamed(
      AppRoutes.returningUserScreen,
    );
  }
}
