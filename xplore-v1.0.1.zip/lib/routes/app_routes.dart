import 'package:xplore/presentation/splash_screen/splash_screen.dart';
import 'package:xplore/presentation/splash_screen/binding/splash_binding.dart';
import 'package:xplore/presentation/returning_user_screen/returning_user_screen.dart';
import 'package:xplore/presentation/returning_user_screen/binding/returning_user_binding.dart';
import 'package:xplore/presentation/landing_page_container1_screen/landing_page_container1_screen.dart';
import 'package:xplore/presentation/landing_page_container1_screen/binding/landing_page_container1_binding.dart';
import 'package:xplore/presentation/service_page_screen/service_page_screen.dart';
import 'package:xplore/presentation/service_page_screen/binding/service_page_binding.dart';
import 'package:xplore/presentation/app_navigation_screen/app_navigation_screen.dart';
import 'package:xplore/presentation/app_navigation_screen/binding/app_navigation_binding.dart';
import 'package:get/get.dart';

class AppRoutes {
  static const String splashScreen = '/splash_screen';

  static const String returningUserScreen = '/returning_user_screen';

  static const String landingPageContainerPage = '/landing_page_container_page';

  static const String landingPageContainer1Screen =
      '/landing_page_container1_screen';

  static const String servicePageScreen = '/service_page_screen';

  static const String appNavigationScreen = '/app_navigation_screen';

  static const String initialRoute = '/initialRoute';

  static List<GetPage> pages = [
    GetPage(
      name: splashScreen,
      page: () => SplashScreen(),
      bindings: [
        SplashBinding(),
      ],
    ),
    GetPage(
      name: returningUserScreen,
      page: () => ReturningUserScreen(),
      bindings: [
        ReturningUserBinding(),
      ],
    ),
    GetPage(
      name: landingPageContainer1Screen,
      page: () => LandingPageContainer1Screen(),
      bindings: [
        LandingPageContainer1Binding(),
      ],
    ),
    GetPage(
      name: servicePageScreen,
      page: () => ServicePageScreen(),
      bindings: [
        ServicePageBinding(),
      ],
    ),
    GetPage(
      name: appNavigationScreen,
      page: () => AppNavigationScreen(),
      bindings: [
        AppNavigationBinding(),
      ],
    ),
    GetPage(
      name: initialRoute,
      page: () => SplashScreen(),
      bindings: [
        SplashBinding(),
      ],
    )
  ];
}
