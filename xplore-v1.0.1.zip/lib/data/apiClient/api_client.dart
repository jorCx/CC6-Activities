import 'package:xplore/core/app_export.dart';

class ApiClient extends GetConnect {}
