class ImageConstant {
  static String imgRectangle6 = 'assets/images/img_rectangle6.png';

  static String imgRectangle7 = 'assets/images/img_rectangle7.png';

  static String imgArrowleft = 'assets/images/img_arrowleft.svg';

  static String imgWhhnotification = 'assets/images/img_whhnotification.svg';

  static String imgDashboardBlack900 =
      'assets/images/img_dashboard_black_900.svg';

  static String imgVideocamera = 'assets/images/img_videocamera.svg';

  static String imgSearchBlack900 = 'assets/images/img_search_black_900.svg';

  static String imgBxbxshome = 'assets/images/img_bxbxshome.svg';

  static String imgRectangle9 = 'assets/images/img_rectangle9.png';

  static String imgBxbxshomeBlack900 =
      'assets/images/img_bxbxshome_black_900.svg';

  static String imgDashboard = 'assets/images/img_dashboard.svg';

  static String imgEllipse2 = 'assets/images/img_ellipse2.png';

  static String imgEllipse3 = 'assets/images/img_ellipse3.png';

  static String imgRectangle3 = 'assets/images/img_rectangle3.png';

  static String imgBipluscirclefillBlack900 =
      'assets/images/img_bipluscirclefill_black_900.svg';

  static String imgRectangle11 = 'assets/images/img_rectangle11.png';

  static String imgSearch = 'assets/images/img_search.svg';

  static String imgRectangle13 = 'assets/images/img_rectangle13.png';

  static String imgEllipse1 = 'assets/images/img_ellipse1.png';

  static String imgStar = 'assets/images/img_star.svg';

  static String imgRectangle10 = 'assets/images/img_rectangle10.png';

  static String imgRectangle5 = 'assets/images/img_rectangle5.png';

  static String imgRectangle8 = 'assets/images/img_rectangle8.png';

  static String imgRectangle4 = 'assets/images/img_rectangle4.png';

  static String imgWhhprofile = 'assets/images/img_whhprofile.svg';

  static String imgBipluscirclefill = 'assets/images/img_bipluscirclefill.svg';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
