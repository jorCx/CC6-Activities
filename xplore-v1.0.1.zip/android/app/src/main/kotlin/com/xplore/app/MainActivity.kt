package com.xplore.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
